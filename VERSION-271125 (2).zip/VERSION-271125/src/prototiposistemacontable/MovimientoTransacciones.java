package prototiposistemacontable;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MovimientoTransacciones extends javax.swing.JFrame {
     
    private final ManejoArchivo manejo = new ManejoArchivo();
    DefaultTableModel model;
     
     ArrayList <String> agregarMovimientos = new ArrayList <>();
     ArrayList <String> modifMovimientos = new ArrayList <>();
     
     boolean editandotransaccion;
     private String user;
     String prefijodoc;
     String serie = null;
     String tipodoc = null;
     double totaldb=0;
     double totalcr=0;
     int hexbgEnt = Integer.parseInt("ffe7c2", 16);
     int hexfgEnt = Integer.parseInt("023536", 16);
     int hexfgExt = Integer.parseInt("ffe7c2", 16);
     int hexbgExt = Integer.parseInt("023536", 16);
     
        
    public MovimientoTransacciones() {
       
        initComponents();
        this.user = GlobalSession.getUsuarioActual(); 
        autorcampo.setText(this.user); 
        autorcampo.setEditable(false);
        this.model = (DefaultTableModel) tabla_e_s.getModel();
        setLocationRelativeTo(null);
        
        String[] opciones = {"Crear", "Modificar"};
        int accion=JOptionPane.showOptionDialog(this, "Seleccione lo que desee hacer", "Acción inicial", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        
        switch (accion) {
            case 0 -> editandotransaccion=false;
            case 1 -> {
                editandotransaccion=true;
                nrodocucampo.setEditable(true);
            }
            default -> JOptionPane.showMessageDialog(null, "Error al captar la accion");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelbase = new javax.swing.JPanel();
        nrodocucampo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        tipodoclabel = new javax.swing.JLabel();
        autorlabel = new javax.swing.JLabel();
        autorcampo = new javax.swing.JTextField();
        cclabel = new javax.swing.JLabel();
        cccampo = new javax.swing.JTextField();
        fechalabel = new javax.swing.JLabel();
        fechacampo = new javax.swing.JTextField();
        montolabel = new javax.swing.JLabel();
        montocampo = new javax.swing.JTextField();
        tipocombo = new javax.swing.JComboBox<>();
        agregarboton = new javax.swing.JButton();
        guardarboton = new javax.swing.JButton();
        limpiarBoton = new javax.swing.JButton();
        salirboton = new javax.swing.JButton();
        descrlabel = new javax.swing.JLabel();
        descrcampo = new javax.swing.JTextField();
        dblabel = new javax.swing.JLabel();
        debcampo = new javax.swing.JTextField();
        crlabel = new javax.swing.JLabel();
        crcampo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_e_s = new javax.swing.JTable();
        horacampo = new javax.swing.JTextField();
        horalabel = new javax.swing.JLabel();
        comentlabel = new javax.swing.JLabel();
        comentcampo = new javax.swing.JTextField();
        nombrectalabel = new javax.swing.JLabel();
        nombrecuenta = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        totdeb = new javax.swing.JTextField();
        totcr = new javax.swing.JTextField();
        autorlabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Movimiento de transacciones");
        setUndecorated(true);

        panelbase.setBackground(new java.awt.Color(255, 231, 194));

        nrodocucampo.setEditable(false);
        nrodocucampo.setBackground(new java.awt.Color(232, 232, 232));
        nrodocucampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nrodocucampo.setBorder(null);
        nrodocucampo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nrodocucampoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Numero de documento: ");

        tipodoclabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tipodoclabel.setText("Tipo de documento:");

        autorlabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        autorlabel.setText("Hecho por: ");

        autorcampo.setEditable(false);
        autorcampo.setBackground(new java.awt.Color(232, 232, 232));
        autorcampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        autorcampo.setBorder(null);

        cclabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cclabel.setText("No. Cuenta:");

        cccampo.setEditable(false);
        cccampo.setBackground(new java.awt.Color(232, 232, 232));
        cccampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cccampo.setBorder(null);
        cccampo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cccampoActionPerformed(evt);
            }
        });

        fechalabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        fechalabel.setText("Fecha:");

        fechacampo.setEditable(false);
        fechacampo.setBackground(new java.awt.Color(232, 232, 232));
        fechacampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        fechacampo.setBorder(null);

        montolabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        montolabel.setText("Monto: ");

        montocampo.setEditable(false);
        montocampo.setBackground(new java.awt.Color(232, 232, 232));
        montocampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        montocampo.setBorder(null);

        tipocombo.setBackground(new java.awt.Color(232, 232, 232));
        tipocombo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tipocombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Factura", "Ajuste", "Depósito", "Asiento de diario", "Orden de compra", "Cheque", "Nota de crédito", "Nota de débito" }));
        tipocombo.setBorder(null);
        tipocombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipocomboActionPerformed(evt);
            }
        });

        agregarboton.setBackground(new java.awt.Color(2, 53, 54));
        agregarboton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        agregarboton.setForeground(new java.awt.Color(255, 231, 194));
        agregarboton.setText("Agregar");
        agregarboton.setBorder(null);
        agregarboton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agregarbotonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                agregarbotonMouseExited(evt);
            }
        });
        agregarboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarbotonActionPerformed(evt);
            }
        });

        guardarboton.setBackground(new java.awt.Color(2, 53, 54));
        guardarboton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        guardarboton.setForeground(new java.awt.Color(255, 231, 194));
        guardarboton.setText("Guardar");
        guardarboton.setBorder(null);
        guardarboton.setEnabled(false);
        guardarboton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                guardarbotonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                guardarbotonMouseExited(evt);
            }
        });
        guardarboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarbotonActionPerformed(evt);
            }
        });

        limpiarBoton.setBackground(new java.awt.Color(2, 53, 54));
        limpiarBoton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        limpiarBoton.setForeground(new java.awt.Color(255, 231, 194));
        limpiarBoton.setText("Limpiar");
        limpiarBoton.setBorder(null);
        limpiarBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                limpiarBotonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                limpiarBotonMouseExited(evt);
            }
        });
        limpiarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarBotonActionPerformed(evt);
            }
        });

        salirboton.setBackground(new java.awt.Color(2, 53, 54));
        salirboton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        salirboton.setForeground(new java.awt.Color(255, 231, 194));
        salirboton.setText("Salir");
        salirboton.setBorder(null);
        salirboton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                salirbotonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                salirbotonMouseExited(evt);
            }
        });
        salirboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirbotonActionPerformed(evt);
            }
        });

        descrlabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descrlabel.setText("Descripción");

        descrcampo.setEditable(false);
        descrcampo.setBackground(new java.awt.Color(232, 232, 232));
        descrcampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descrcampo.setBorder(null);

        dblabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        dblabel.setText("Débito: ");

        debcampo.setEditable(false);
        debcampo.setBackground(new java.awt.Color(232, 232, 232));
        debcampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        debcampo.setBorder(null);
        debcampo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                debcampoActionPerformed(evt);
            }
        });

        crlabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        crlabel.setText("Crédito: ");

        crcampo.setEditable(false);
        crcampo.setBackground(new java.awt.Color(232, 232, 232));
        crcampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        crcampo.setBorder(null);
        crcampo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crcampoActionPerformed(evt);
            }
        });

        tabla_e_s.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 12)); // NOI18N
        tabla_e_s.setForeground(new java.awt.Color(2, 53, 54));
        tabla_e_s.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No. Documento", "Secuencia", "Cuenta", "Descripción", "Débito", "Crédito", "Comentario"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla_e_s.setSelectionBackground(new java.awt.Color(247, 221, 181));
        jScrollPane1.setViewportView(tabla_e_s);

        horacampo.setEditable(false);
        horacampo.setBackground(new java.awt.Color(232, 232, 232));
        horacampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        horacampo.setBorder(null);

        horalabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        horalabel.setText("Hora:");

        comentlabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        comentlabel.setText("Comentario: ");

        comentcampo.setEditable(false);
        comentcampo.setBackground(new java.awt.Color(232, 232, 232));
        comentcampo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        comentcampo.setBorder(null);

        nombrectalabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nombrectalabel.setText("Nombre:");

        nombrecuenta.setEditable(false);
        nombrecuenta.setBackground(new java.awt.Color(232, 232, 232));
        nombrecuenta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nombrecuenta.setBorder(null);

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(2, 53, 54));
        jLabel4.setText("TRANSACCIONES");

        totdeb.setEditable(false);
        totdeb.setBackground(new java.awt.Color(232, 232, 232));
        totdeb.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totdeb.setForeground(new java.awt.Color(2, 53, 54));
        totdeb.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        totdeb.setBorder(null);

        totcr.setEditable(false);
        totcr.setBackground(new java.awt.Color(232, 232, 232));
        totcr.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totcr.setForeground(new java.awt.Color(2, 53, 54));
        totcr.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        totcr.setBorder(null);

        autorlabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        autorlabel1.setText("Totales:");

        javax.swing.GroupLayout panelbaseLayout = new javax.swing.GroupLayout(panelbase);
        panelbase.setLayout(panelbaseLayout);
        panelbaseLayout.setHorizontalGroup(
            panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelbaseLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelbaseLayout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelbaseLayout.createSequentialGroup()
                        .addComponent(agregarboton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(guardarboton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(limpiarBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(salirboton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                        .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1)
                            .addGroup(panelbaseLayout.createSequentialGroup()
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(panelbaseLayout.createSequentialGroup()
                                        .addComponent(descrlabel)
                                        .addGap(29, 29, 29)
                                        .addComponent(descrcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelbaseLayout.createSequentialGroup()
                                        .addComponent(tipodoclabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tipocombo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addComponent(nrodocucampo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(37, 37, 37)
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(panelbaseLayout.createSequentialGroup()
                                        .addComponent(fechalabel)
                                        .addGap(34, 34, 34)
                                        .addComponent(fechacampo))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                                        .addComponent(horalabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(horacampo, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                                        .addComponent(autorlabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(autorcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(50, 50, 50)
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelbaseLayout.createSequentialGroup()
                                        .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(nombrectalabel)
                                            .addGroup(panelbaseLayout.createSequentialGroup()
                                                .addComponent(montolabel)
                                                .addGap(48, 48, 48)
                                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(nombrecuenta, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                                    .addComponent(montocampo))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(panelbaseLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(crlabel)
                                                .addGap(18, 18, 18)
                                                .addComponent(crcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(panelbaseLayout.createSequentialGroup()
                                                .addComponent(dblabel)
                                                .addGap(23, 23, 23)
                                                .addComponent(debcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(panelbaseLayout.createSequentialGroup()
                                        .addComponent(cclabel)
                                        .addGap(24, 24, 24)
                                        .addComponent(cccampo, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                                        .addComponent(comentlabel)
                                        .addGap(18, 18, 18)
                                        .addComponent(comentcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(50, 50, 50))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(autorlabel1)
                .addGap(36, 36, 36)
                .addComponent(totdeb, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(totcr, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(222, 222, 222))
        );
        panelbaseLayout.setVerticalGroup(
            panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(panelbaseLayout.createSequentialGroup()
                            .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tipodoclabel)
                                    .addComponent(tipocombo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(fechalabel)
                                    .addComponent(fechacampo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(nrodocucampo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(horalabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(horacampo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(descrcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(descrlabel))
                                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(autorcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(autorlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(montolabel))))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelbaseLayout.createSequentialGroup()
                            .addComponent(debcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(crcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(crlabel)
                                .addComponent(montocampo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelbaseLayout.createSequentialGroup()
                        .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cclabel)
                            .addComponent(cccampo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comentcampo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comentlabel))
                        .addGap(18, 18, 18)
                        .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nombrectalabel)
                            .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(nombrecuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(dblabel)))))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totdeb, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totcr, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(autorlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(panelbaseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(agregarboton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(limpiarBoton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salirboton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(guardarboton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelbase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelbase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        
      
        
    private void limpiarBotonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limpiarBotonMouseEntered
        limpiarBoton.setBackground(new Color(hexbgEnt));
        limpiarBoton.setForeground(new Color(hexfgEnt));
    }//GEN-LAST:event_limpiarBotonMouseEntered

    private void limpiarBotonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limpiarBotonMouseExited
        limpiarBoton.setBackground(new Color(hexbgExt));
        limpiarBoton.setForeground(new Color(hexfgExt));
    }//GEN-LAST:event_limpiarBotonMouseExited

    private void limpiarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarBotonActionPerformed
        limpiarCamposCompletos();
        setEnabledFalseCampos();
    }//GEN-LAST:event_limpiarBotonActionPerformed

    private void salirbotonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salirbotonMouseEntered
        salirboton.setBackground(new Color(hexbgEnt));
        salirboton.setForeground(new Color(hexfgEnt));
    }//GEN-LAST:event_salirbotonMouseEntered

    private void salirbotonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salirbotonMouseExited
        salirboton.setBackground(new Color(hexbgExt));
        salirboton.setForeground(new Color(hexfgExt));
    }//GEN-LAST:event_salirbotonMouseExited

    private void salirbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirbotonActionPerformed
        this.dispose();
    }//GEN-LAST:event_salirbotonActionPerformed

    private void guardarbotonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guardarbotonMouseEntered
        guardarboton.setBackground(new Color(hexbgEnt));
        guardarboton.setForeground(new Color(hexfgEnt));
    }//GEN-LAST:event_guardarbotonMouseEntered

    private void guardarbotonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guardarbotonMouseExited
    guardarboton.setBackground(new Color(hexbgExt));
    guardarboton.setForeground(new Color(hexfgExt));
    }//GEN-LAST:event_guardarbotonMouseExited

    private void guardarbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarbotonActionPerformed
    int respuesta = javax.swing.JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea guardar?",
            "Sí",
            javax.swing.JOptionPane.YES_NO_OPTION);

    if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
        
        String nrodoc = nrodocucampo.getText().trim();
        String fecha = fechacampo.getText().trim();
        String hora = horacampo.getText().trim();
        String tipo = tipocombo.getSelectedItem().toString().trim();
        String descrip = descrcampo.getText().trim();
        String usuario=user;
        String fechaact = "-";
        boolean estadodoc=false;
        double monto=totaldb-totalcr;
        
        if(editandotransaccion){
            estadodoc=true;
            
            LocalDateTime now = LocalDateTime.now();//SE TIENE QUE MODIFICAR EL ESTADO DE CUENTA Y LA FECH DE ACT...
            DateTimeFormatter dateF = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            fechaact=now.format(dateF);
            
            String nuevaCab = nrodoc+";"+fecha+";"+hora+";"+tipo+";"+descrip+";"+usuario+";"+monto+";"+fechaact+";"+estadodoc+";";
            
            manejo.crearTransaccion("src/CabeceraTransaccionContable.txt", nuevaCab);
            
            for(String cadena: agregarMovimientos){
                manejo.crearTransaccion("src/Transacciones.txt", cadena);
            }
            
            agregarMovimientos.clear();
            guardarboton.setEnabled(false);
            
            JOptionPane.showMessageDialog(null, "Guardado.");
        }else{
        String lineaCabecera = nrodoc+";"+fecha+";"+hora+";"+tipo+";"+descrip+";"+usuario+";"+monto+";"+fechaact+";"+estadodoc+";";
        
        manejo.crearTransaccion("src/CabeceraTransaccionContable.txt", lineaCabecera);
        
        for(String cadena: agregarMovimientos){
            manejo.crearTransaccion("src/Transacciones.txt", cadena); //agrega los movimientos creados
        }
        
        agregarMovimientos.clear(); //... limpia la lista por si se quiere seguir con el proceso
        guardarboton.setEnabled(false);
        JOptionPane.showMessageDialog(null, "Guardado de manera correcta.");
        tipocombo.setSelectedIndex(0);
        fechacampo.setText("");
        horacampo.setText("");
        autorcampo.setText("");
        descrcampo.setText("");
        montocampo.setText("");
        nrodocucampo.setText("");
        } 
    
    }
    }//GEN-LAST:event_guardarbotonActionPerformed
//AGREGAR
    private void agregarbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarbotonActionPerformed
        if (cccampo.getText().equals("") || (debcampo.getText().equals("") && crcampo.getText().equals(""))) {
        JOptionPane.showMessageDialog(null, "Llene campos faltantes relacionados a la cuenta.");
        }
        else{
        String comentario="-";
        double debito=0.0;
        double credito=0.0;
        int sec = 0;
            
        String num = nrodocucampo.getText().trim();
        
        if(serie!=null && !serie.isEmpty()){
            try{
                sec = Integer.parseInt(serie.trim());
            }catch(NumberFormatException e){
                sec=0;
            }
        }
        
        String cuenta=cccampo.getText().trim();
        
        String descripcion = nombrecuenta.getText().trim();
        
        if(!debcampo.getText().equals("")){
        debito = Double.parseDouble(debcampo.getText().trim());
        totaldb+=debito;
        totdeb.setText(String.valueOf(totaldb));
        }
        if(!crcampo.getText().equals("")){
        credito = Double.parseDouble(crcampo.getText().trim());
        totalcr+=credito;
        totcr.setText(String.valueOf(totalcr));
        }
        if(!comentcampo.getText().equals("")){
        comentario = comentcampo.getText().trim();
        }
        
        String nuevaLinea = num+";"+sec+";"+cuenta+";"+debito+";"+credito+";"+comentario+";";
        
        agregarMovimientos.add(nuevaLinea);
        
        agregarFilaEnTabla(num, sec, cuenta, descripcion, debito, credito, comentario);
        
        crcampo.setEnabled(true);
        debcampo.setEnabled(true);
        
        guardarboton.setEnabled(totdeb.getText().equals(totcr.getText())); 
        }
    }//GEN-LAST:event_agregarbotonActionPerformed

    private void agregarbotonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarbotonMouseExited
        agregarboton.setBackground(new Color(hexbgExt));
        agregarboton.setForeground(new Color(hexfgExt));
    }//GEN-LAST:event_agregarbotonMouseExited

    private void agregarbotonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarbotonMouseEntered
        agregarboton.setBackground(new Color(hexbgEnt));
        agregarboton.setForeground(new Color(hexfgEnt));
    }//GEN-LAST:event_agregarbotonMouseEntered

    private void cccampoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cccampoActionPerformed
        String linea = manejo.lecturaCuenta(cccampo.getText().trim());
        
        if(linea.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,"La cuenta solicitada no existe.");
        } else{
            String[] partes =linea.split(";");
            String tipoCta=partes[2].trim();
            switch (tipoCta) {
            case "General", "GENERAL", "general" -> JOptionPane.showMessageDialog(null,"La cuenta "+partes[1].trim()+" es general. Solo se permiten cuentas de detalle.");
            default -> {
                nombrecuenta.setText(partes[1].trim());
                comentcampo.setEditable(true);
                debcampo.setEditable(true);
                crcampo.setEditable(true);
            }
            }
        }
    }//GEN-LAST:event_cccampoActionPerformed
        
    private void tipocomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipocomboActionPerformed
        
        if(!editandotransaccion){
        tipodoc=tipocombo.getSelectedItem().toString().trim();

        prefijodoc = switch (tipodoc) {
            case "Ajuste" -> "AJT";
            case "Depósito" -> "DP";
            case "Asiento de diario" -> "AST";
            case "Orden de compra" -> "ODC";
            case "Cheque" -> "CQ";
            case "Nota de débito" -> "NDT";
            case "Nota de crédito" -> "NCR";
            default -> "FACT";
        };
        boolean existe;
        
        for (int cont = 0; cont <= 999999; cont++) {
           serie = String.format("%06d", cont);
           
           existe=manejo.busquedaNoDocTrans(prefijodoc+serie);

           if (!existe){ //si no, rompe y el num de serie generado se queda
                break;
           }
        }
     
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dateF = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter timeF = DateTimeFormatter.ofPattern("HH:mm:ss");
    
        String fechaCreacion = now.format(dateF);
        String horaCreacion = now.format(timeF);
        
        nrodocucampo.setText(prefijodoc+serie);
        descrcampo.setEditable(true);
        fechacampo.setText(fechaCreacion);
        horacampo.setText(horaCreacion);
        autorcampo.setText(user);
        cccampo.setEditable(true);
        
        tipocombo.setEnabled(false);
        
        editandotransaccion=true;
        } 
        else{
            char[] prefijoev = new char[5];
            
            String nro=nrodocucampo.getText().trim();
            for (int i = 0; i < nro.length(); i++) {
                
            char c = nro.charAt(i);
            
               if (!Character.isDigit(c)) {
                   prefijoev[i]=c;
                   break;
               }
               
            }
            
            String prefijo = new String(prefijoev).trim();
            String prefijoconcat="";
            
            for (int k = 0; k < prefijo.length(); k++) {
                char cp = prefijo.charAt(k);
                    if(!Character.isDigit(cp) && cp != '\0'){
                        prefijoconcat = prefijoconcat+cp;
                    }
            }
            
            switch (prefijoconcat) {
                case "FACT" -> tipocombo.setSelectedIndex(0);
                case "AJT" -> tipocombo.setSelectedIndex(1);
                case "DP" -> tipocombo.setSelectedIndex(2);
                case "AST" -> tipocombo.setSelectedIndex(3);
                case "ODC" -> tipocombo.setSelectedIndex(4);
                case "CQ" -> tipocombo.setSelectedIndex(5);
                case "NDT" -> tipocombo.setSelectedIndex(6);
                default -> tipocombo.setSelectedIndex(7);
            }
        }
    }//GEN-LAST:event_tipocomboActionPerformed

    private void debcampoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_debcampoActionPerformed
        String texto = debcampo.getText().trim();
        boolean todosDigitos = true;

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if (!Character.isDigit(c)) {
               todosDigitos = false;
               break;
            }
        }
        String formatoPunto = "^\\d+(\\.\\d+)?$";
        String formatoComa  = "^\\d+(,\\d+)?$";

        if (!todosDigitos) {
            if (!texto.matches(formatoPunto) && !texto.matches(formatoComa)) {
                JOptionPane.showMessageDialog(null, "El monto no es válido. Debe ser un número entero o decimal.");
            }
        } else {
        crcampo.setEnabled(false);
        } 
    }//GEN-LAST:event_debcampoActionPerformed

    private void crcampoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crcampoActionPerformed
       String texto = crcampo.getText().trim();
        boolean todosDigitos = true;

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if (!Character.isDigit(c)) {
               todosDigitos = false;
               break;
            }
        }
        String formatoPunto = "^\\d+(\\.\\d+)?$";
        String formatoComa  = "^\\d+(,\\d+)?$";

        if (!todosDigitos) {
            if (!texto.matches(formatoPunto) && !texto.matches(formatoComa)) {
                JOptionPane.showMessageDialog(null, "El monto no es válido. Debe ser un número entero o decimal.");
            }
        } else {
        debcampo.setEnabled(false);
        } 
    }//GEN-LAST:event_crcampoActionPerformed

    private void nrodocucampoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nrodocucampoActionPerformed
        // SOLO REALIZA CUANDO SE MODIFICA
        if (!editandotransaccion) {
        return; 
        }
        
        String nroDocumento = nrodocucampo.getText().trim();
        if (nroDocumento.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un número de documento.");
        return;
        }

        boolean existe = manejo.busquedaNoDocTrans(nroDocumento);

        if (!existe) {
             JOptionPane.showMessageDialog(this, "El documento no existe."); //DAR OPCION DE ELEGIR SI CREAR O INGRESAR AGAIN
        return;
        }
                                                                         //ACUERDATE DE PONERLE ACCION AL COMBO DEPENDIENDO DE LA ACCION
        String linea = manejo.busquedaDocTrans(nroDocumento);
        String[] partes = linea.split(";");
        boolean actualizado = Boolean.parseBoolean(partes[7]);

        if (actualizado) {
             JOptionPane.showMessageDialog(this, "El documento ya fue actualizado.");
        }else{
             descrcampo.setText(partes[4].trim());
             fechacampo.setText(partes[1]);
             horacampo.setText(partes[2]);
             autorcampo.setText(partes[5]);
             
             modifMovimientos.clear();
             
            try{
                 BufferedReader buffer = new BufferedReader(new FileReader("src/transacciones.txt"));
                 String lineadoc;
                 
                 while((lineadoc=buffer.readLine())!=null){
                     String[] movs=lineadoc.split(";");
                     
                     if(movs.length>0 && movs[0].trim().equals(nroDocumento)){
                         modifMovimientos.add(lineadoc);
                     }
                 }
            } catch (IOException ex) {
                Logger.getLogger(MovimientoTransacciones.class.getName()).log(Level.SEVERE, null, ex);
                return;
            }
            
            cargarTablaCompleta();
            JOptionPane.showMessageDialog(this, "Documento cargado correctamente.");
        }
    }//GEN-LAST:event_nrodocucampoActionPerformed
        
        private void setEnabledFalseCampos(){
        fechacampo.setEnabled(false);
        autorcampo.setEnabled(false);
        }
        private void limpiarCamposCompletos (){
        cccampo.setText("");
        montocampo.setText("");
        debcampo.setText("");
        crcampo.setText("");
        comentcampo.setText("");
        nombrecuenta.setText("");
        tipodoc = null;
        editandotransaccion=false;
        }
        
        private void cargarTablaCompleta(){
             String nro, sec, nroCta, cta, deb, cr, comentario;
             
            for(String mov: modifMovimientos){
                String[] partestabla = mov.split(";");
                
                nro=partestabla[0].trim();
                sec=partestabla[1].trim();
                nroCta=partestabla[2].trim();
                cta=obtenerNombreCuenta(nroCta);
                deb=partestabla[3].trim();
                cr=partestabla[4].trim();
                comentario=partestabla[5].trim();
                
                Object[] datos = { 
                nro,
                sec,
                Integer.valueOf(nroCta),
                cta,
                deb,
                cr,
                comentario};
                
                model.addRow(datos);
            }
        }
        
        private void agregarFilaEnTabla(String nro, int sec, String nroCta, String cta, double deb, double cr, String comentario) {

        try {
            validarEntero("Número de Cuenta", nroCta);

            Object[] datos = { 
                nro,
                sec,
                Integer.valueOf(nroCta),
                cta,
                deb,
                cr,
                comentario
            };
            model.addRow(datos);

    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(
            null,
            e.getMessage(),
            "Error de Datos",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
    }
        private void validarEntero(String campo, String valor) {
            if (valor == null || !valor.matches("\\d+")) {
               throw new NumberFormatException("El campo \"" + campo + "\" debe contener solo dígitos enteros.");
            }
        }
        
        private String obtenerNombreCuenta(String no){
            File archivoCtas = new File("src/Cuentas.txt");
            if(!archivoCtas.exists()){
                JOptionPane.showMessageDialog(null, "El archivo de cuentas no existe.");
            }
            try(BufferedReader buffer = new BufferedReader(new FileReader(archivoCtas))){
                String linea;
                
                while((linea=buffer.readLine())!=null){
                    String[] partes = linea.split(";");
                    
                    if(partes.length>=2 && partes[0].trim().equals(no)){
                        return partes[1].trim();
                    }
                }
                
            } catch (IOException ex) {
            Logger.getLogger(MovimientoTransacciones.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        }
        
        public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MovimientoTransacciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new MovimientoTransacciones().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agregarboton;
    private javax.swing.JTextField autorcampo;
    private javax.swing.JLabel autorlabel;
    private javax.swing.JLabel autorlabel1;
    private javax.swing.JTextField cccampo;
    private javax.swing.JLabel cclabel;
    private javax.swing.JTextField comentcampo;
    private javax.swing.JLabel comentlabel;
    private javax.swing.JTextField crcampo;
    private javax.swing.JLabel crlabel;
    private javax.swing.JLabel dblabel;
    private javax.swing.JTextField debcampo;
    private javax.swing.JTextField descrcampo;
    private javax.swing.JLabel descrlabel;
    private javax.swing.JTextField fechacampo;
    private javax.swing.JLabel fechalabel;
    private javax.swing.JButton guardarboton;
    private javax.swing.JTextField horacampo;
    private javax.swing.JLabel horalabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton limpiarBoton;
    private javax.swing.JTextField montocampo;
    private javax.swing.JLabel montolabel;
    private javax.swing.JLabel nombrectalabel;
    private javax.swing.JTextField nombrecuenta;
    private javax.swing.JTextField nrodocucampo;
    private javax.swing.JPanel panelbase;
    private javax.swing.JButton salirboton;
    private javax.swing.JTable tabla_e_s;
    private javax.swing.JComboBox<String> tipocombo;
    private javax.swing.JLabel tipodoclabel;
    private javax.swing.JTextField totcr;
    private javax.swing.JTextField totdeb;
    // End of variables declaration//GEN-END:variables
}